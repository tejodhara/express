const express= require("express");
const expressHandlebars= require("express-handlebars");
const mongoose= require("mongoose");
const productRoute = require("./routes/products.js");   //connecting all the controllers from the routes
const app= express();
const port=9089;


// Mongodb Atlas Data Base link taken and assigned to a variable
// go to mongodb atlas cloud >connect cluster > connect your application > copy the db url
// mongodb+srv://jithin:<password>@cluster0.jf7kz.mongodb.net/?retryWrites=true&w=majority 
// the above link is the Atlas cloud connection link
// remove <password> and type mongodb atlas password
const dbUrl = "mongodb+srv://jithin:atlasmongo@cluster0.jf7kz.mongodb.net/?retryWrites=true&w=majority";


//connecting Mongodb Atlas Data Base link with mongoose >> express app
mongoose.connect(dbUrl,{useNewUrlParser:true,useUnifiedTopology:true})
.then(()=>{
    console.log("DB connected successfully");
}).catch((err)=>{
    console.log(err)
});

//or 
// now connecting Mongoose & mongoDB 
// mongoose.connect(dbUrl,{useNewUrlParser:true,useUnifiedTopology:true},
//     (err)=>{
//         if(!err){
//         console.log("connected successfully");
//         }else {
//             console.log(err)
//             console.log("DB Connection Failed");
//         }
//     }
//     );



//setting engine
app.engine("handlebars", expressHandlebars.engine()) 
app.set("view engine", "handlebars")


//body parser middleware
app.use(express.urlencoded({extended:true}));

// Router middleware
//'/products' is the base url/path ,this products we have to add to all the paths of controllers & handlebars path
app.use('/products',productRoute);   


// controller for Landing Page
app.get("/", (req, res) => {

    res.render("./landingPage.handlebars")
})



app.listen(port, () => console.log(`Server is listening to port ${port}`))