const mongoose = require('mongoose')

const Schema = mongoose.Schema;


// creating schema
const productSchema = mongoose.Schema({
    pName: {
        type: String,
        require: true,
    },
    pDesc: {
        type: String,
        require: true
    },
    pPrice:{
        type:Number,
        require:true,
    },

})



// now export the schema to modals folder
module.exports = mongoose.model('product',productSchema);

//or

// const collection = mongoose.model('products',productSchema);
// module.exports = {collection};