const express = require("express");
const router = express.Router();    //using router we can connect the endpoints
const product = require("../modals/products");  // importing the schema



// controller for add product
// rendering addProducts handlebar
router.get("/add-products", (req, res) => {
    res.render("./addProducts.handlebars");
});



// creating endpoint for monolothic application
// we use async & await for every data pushing to DB
//async & await is used so as to insert first data and after successfull pushing only go to the next data
//here data is getting from front end
router.post("/products/add", async (req, res) => {
    // console.log(req.body);
    let { pName, pDesc, pPrice } = req.body   //req.body is the object containing { pName, pDesc, pPrice } & gives to Back end  
    try {
        await product.insertMany({             // instead of pushing , we are sending it to DB, product is the schema 
            pName,
            pDesc,
            pPrice,
        });
        res.redirect("/products/products");
    } catch (err) {
        console.log(err)
    }
});

// read products froom MongoDB Atlas DB to the navbar
router.get('/products', async (req, res) => {
    try {
        //getting data from data base as mongoose object to back end application 
        // lean method convert mongoose object to java script object
        //find() will give the entire document
        const data = await product.find().lean()
        console.log("data >>", data)
        res.render("./products.handlebars", { data })
    } catch (err) {
        console.log(err)
    }
})


//edit product
// monolothic app will not support put http method , hence get is been used
router.get('/product/edit-product/:_id', async (req, res) => {

    const _id = req.params._id   // we are getting id from params
    try {
        const selectedDocs = await product.findOne({
            _id,
        }).lean();
        console.log("selectedDocs >>", selectedDocs)

        res.render('./editProducts.handlebars', { selectedDocs })
    } catch (err) {
        console.log(err)
    }
})


// updating the edited products in the mongo Atlas DB
router.post("/edit-product/:_id", async (req, res) => {
    let { pName, pDesc, pPrice, } = req.body;
    const _id = req.params._id;
    try {
        //product is the name of collection
        await product.updateOne({ _id }, {
            $set: {
                _id, pName, pDesc, pPrice
            },
        })
        res.redirect("/products/products");
    } catch (err) {
        console.log(err)
    }
})


// delete products
router.get("/delete-product/:_id", async (req, res) => {
    const _id = req.params._id;
    try {
        await product.deleteOne({ _id }); res.redirect("/products/products")
    } catch (err) {
        console.log(err)
    }
});


module.exports = router;  // to connect with the app